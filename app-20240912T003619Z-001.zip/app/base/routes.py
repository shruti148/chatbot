# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from flask import jsonify, render_template, redirect, request, url_for

from app.base import blueprint

@blueprint.route('/', methods=['GET', 'POST'])
def login():
    return redirect(url_for('home_blueprint.index'))
